package com.example.galleryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;



public class PictureAdapter extends RecyclerView.Adapter<PictureAdapter.MyViewHolder> {
    String data1[], data2[];
    Context context;

    public PictureAdapter(Context ct, String[] s1){
    context =ct;
    data1=s1;

    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.eachpicture,parent,false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Picasso.with(context)
                .load(String.valueOf(data1[position]))

                .resize(750, 630)
                .into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return data1.length;
    }

    public class MyViewHolder  extends RecyclerView.ViewHolder{

        ImageView imageView;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
       imageView = itemView.findViewById(R.id.displayImage);
        }
    }

}
