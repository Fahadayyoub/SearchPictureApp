package com.example.galleryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.MergeCursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.FrameLayout;

import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
        } catch (Exception e) {
            e.printStackTrace();
        }
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new Pictures() ).commit();
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedFragment = null;
                    switch (item.getItemId()){
        case R.id.pictures:
            selectedFragment = new Pictures();
            break;
        case R.id.videos:
            selectedFragment = new Videos();
            break;
        case R.id.information:
            selectedFragment = new Information();
            break;
    }
                FrameLayout fl = (FrameLayout) findViewById(R.id.fragment);
                fl.removeAllViews();
    getSupportFragmentManager().beginTransaction().replace(R.id.fragment,selectedFragment).commit();
                return true;
            }
        });

    }}