package com.example.galleryapp;

import android.app.Dialog;
import android.content.ContentResolver;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Pictures#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Pictures extends Fragment {
    private List<String> show_amount = new ArrayList<>();
   private ListView listView;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Pictures() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Pictures.
     */
    // TODO: Rename and change types and number of parameters
    public static Pictures newInstance(String param1, String param2) {
        Pictures fragment = new Pictures();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pictures,
                container, false);
        ContentResolver contentResolver = getContext().getContentResolver();
         listView=(ListView) view.findViewById(R.id.getUserRequest);;
        final EditText KeyWord= view.findViewById(R.id.KeyWord);
        ImageView search= view.findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {

                RequestQueue queue = Volley.newRequestQueue(getContext());
             String value=   KeyWord.getText().toString();


                String url ="https://pixabay.com/api/?key=20170808-1cc09fbf542d67d2e52825c28&q="+value+"&image_type=photo";
//                String url ="http://tnmco.uk/Mobile/mobile.php/register";
                final Stack<String> pictureUrls = new Stack<String>();
                show_amount.clear();
                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject jsonObject = new JSONObject(response);
                                    JSONArray posts = jsonObject.getJSONArray("hits");
                                    for (int i = 0; i < posts.length(); i++) {
                                        JSONObject fileObj = posts.getJSONObject(i);
                                        show_amount.add(String.valueOf(fileObj.getString("previewURL")));
//                                        pictureUrls.push(String.valueOf(fileObj.getString("previewURL")));
                                        String fName = fileObj.getString("previewURL");
                                    }
                                    CustomeAdapter customeAdapter = new CustomeAdapter();
                                    listView.setAdapter(customeAdapter);

//                                    displayresult(view);
                                        } catch (JSONException e) {
                                    e.printStackTrace();
                                }





                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        error.printStackTrace();
                        Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){

                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<String, String>();

                        return params;
                    }};
                stringRequest.setShouldCache(false);
                queue.add(stringRequest);
            }
        });

//

        return view;
    }
    public void displayresult(View view){
//
    }
    class CustomeAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return Integer.valueOf(show_amount.size());
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return Integer.valueOf(show_amount.size());
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            convertView = getLayoutInflater().inflate(R.layout.eachpicture, null);

            ImageView imageView = (ImageView) convertView.findViewById(R.id.displayImage);
            Picasso.with(getContext())
                    .load(String.valueOf(show_amount.get(position)))

                    // .load( String.valueOf(merchantImage.get(position)))
                    .resize(750, 630)
                    .into(imageView);



            return convertView;
        }
    }

}